"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api, EditorialCard } from "@/lib/api/client";
import { useSocket } from "@/lib/hooks/use-socket";
import { Plus, Radio, EyeOff, Trash2, Wand2 } from "lucide-react";
import { cn } from "@/lib/utility/utils";

const CARD_TYPES = [
  "fixture_intro", "lineups", "standings", "form",
  "head_to_head", "top_scorers", "match_summary", "countdown", "custom",
] as const;

export function EditorialPanel() {
  const params = useParams<{ sessionId: string }>();
  const [cards, setCards] = useState<EditorialCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);

  const refresh = async () => {
    try {
      setCards(await api.listEditorialCards(params.sessionId));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, [params.sessionId]);

  useSocket<EditorialCard>(`/ws/v1/show-sessions/${params.sessionId}`, (msg) => {
    if (msg.type === "editorial.update") refresh();
  });

  const seedAndBroadcast = async (cardType: string) => {
    setBusy(cardType);
    try {
      const card = await api.seedEditorialCard(params.sessionId, cardType);
      await api.broadcastEditorialCard(params.sessionId, card.id);
      await refresh();
    } finally {
      setBusy(null);
      setShowNew(false);
    }
  };

  const broadcast = async (id: string) => {
    setBusy(id);
    try {
      await api.broadcastEditorialCard(params.sessionId, id);
      await refresh();
    } finally { setBusy(null); }
  };

  const hideAll = async () => {
    setBusy("hide");
    try {
      await api.hideAllEditorial(params.sessionId);
      await refresh();
    } finally { setBusy(null); }
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this card?")) return;
    await api.deleteEditorialCard(params.sessionId, id);
    refresh();
  };

  return (
    <div className="flex flex-col gap-2 rounded-lg border border-zinc-800 bg-zinc-900/50 p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500">
          Pre / Post Match
        </div>
        <div className="flex gap-1">
          <button
            onClick={hideAll}
            disabled={busy === "hide"}
            className="rounded p-1 text-zinc-400 hover:bg-zinc-800 disabled:opacity-40"
            title="Hide all"
          >
            <EyeOff className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={() => setShowNew((v) => !v)}
            className="rounded p-1 text-zinc-400 hover:bg-zinc-800"
            title="New card"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {showNew && (
        <div className="rounded border border-zinc-700 bg-zinc-950 p-2">
          <div className="mb-1 text-[10px] uppercase tracking-wider text-zinc-500">
            Seed from match
          </div>
          <div className="flex flex-wrap gap-1">
            {CARD_TYPES.map((t) => (
              <button
                key={t}
                onClick={() => seedAndBroadcast(t)}
                disabled={busy === t}
                className="flex items-center gap-1 rounded bg-zinc-800 px-2 py-1 text-[11px] text-zinc-200 hover:bg-zinc-700 disabled:opacity-40"
              >
                <Wand2 className="h-3 w-3" /> {t.replace(/_/g, " ")}
              </button>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <p className="text-xs text-zinc-500">Loading…</p>
      ) : cards.length === 0 ? (
        <p className="text-xs text-zinc-500">No cards yet.</p>
      ) : (
        cards.map((c) => (
          <div
            key={c.id}
            className={cn(
              "flex items-center gap-2 rounded border px-2 py-1.5 text-xs",
              c.visible
                ? "border-emerald-600 bg-emerald-600/10 text-emerald-200"
                : "border-zinc-800 bg-zinc-950/40 text-zinc-300"
            )}
          >
            <span className="flex-1 truncate">{c.title}</span>
            <span className="rounded bg-zinc-800 px-1.5 text-[10px] text-zinc-400">
              {c.card_type}
            </span>
            <button
              onClick={() => broadcast(c.id)}
              disabled={busy === c.id}
              className="rounded p-1 hover:bg-zinc-800 disabled:opacity-40"
              title="Broadcast"
            >
              <Radio className="h-3 w-3" />
            </button>
            <button
              onClick={() => remove(c.id)}
              className="rounded p-1 text-zinc-500 hover:bg-red-900/40 hover:text-red-400"
              title="Delete"
            >
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        ))
      )}
    </div>
  );
}