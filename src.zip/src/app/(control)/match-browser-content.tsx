"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, ChevronRight, Play, X } from "lucide-react";
import { api } from "@/lib/api/client";
import type { Fixture, ShowProfile, ShowSession } from "@/lib/types/types";
import { useShowStore } from "@/lib/stores/show-store";

/* ---------- config & types ---------- */

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8000";

type Filter = "all" | "live" | "today";
type CommentaryMode = ReturnType<typeof useShowStore.getState>["commentaryMode"];

const DEFAULT_MODE = "approval" as unknown as CommentaryMode;
const STATUS_ORDER: Record<string, number> = { live: 0, scheduled: 1, ft: 2 };
const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "live", label: "Live" },
  { id: "today", label: "Today" },
];

/* ---------- helpers ---------- */

function isToday(iso: string) {
  return new Date(iso).toDateString() === new Date().toDateString();
}

function dayLabel(iso: string) {
  const d = new Date(iso);
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  if (isToday(iso)) return "Today";
  if (d.toDateString() === tomorrow.toDateString()) return "Tomorrow";
  return d.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

type DayGroup = { key: string; label: string; competitions: { name: string; fixtures: Fixture[] }[] };

function groupFixtures(fixtures: Fixture[]): DayGroup[] {
  const sorted = fixtures.slice().sort((a, b) => {
    const da = new Date(a.kickoff);
    const db = new Date(b.kickoff);
    const dayDiff = new Date(da.toDateString()).getTime() - new Date(db.toDateString()).getTime();
    if (dayDiff !== 0) return dayDiff;
    const s = (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9);
    return s !== 0 ? s : da.getTime() - db.getTime();
  });

  const days = new Map<string, DayGroup>();
  for (const f of sorted) {
    const key = new Date(f.kickoff).toDateString();
    const name = f.competition || "Other fixtures";
    let day = days.get(key);
    if (!day) {
      day = { key, label: dayLabel(f.kickoff), competitions: [] };
      days.set(key, day);
    }
    let comp = day.competitions.find((c) => c.name === name);
    if (!comp) {
      comp = { name, fixtures: [] };
      day.competitions.push(comp);
    }
    comp.fixtures.push(f);
  }
  return Array.from(days.values());
}

/* ---------- main component ---------- */

export function MatchBrowserContent() {
  const router = useRouter();
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [profiles, setProfiles] = useState<ShowProfile[]>([]);
  const [profileId, setProfileId] = useState<string>("");
  const [activeSession, setActiveSession] = useState<ShowSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState<string | null>(null);
  const [resuming, setResuming] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");

  useEffect(() => {
    let cancelled = false;
    Promise.all([api.fixtures(), api.listProfiles(), api.listSessions("live,paused,degraded")])
      .then(([f, p, sessions]) => {
        if (cancelled) return;
        setFixtures(f);
        setProfiles(p);
        setProfileId(p[0]?.id ?? "");
        setActiveSession(sessions[0] ?? null);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : "Couldn't load matches.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const counts = useMemo(
    () => ({
      all: fixtures.length,
      live: fixtures.filter((f) => f.status === "live").length,
      today: fixtures.filter((f) => isToday(f.kickoff)).length,
    }),
    [fixtures],
  );

  const grouped = useMemo(() => {
    const list =
      filter === "live"
        ? fixtures.filter((f) => f.status === "live")
        : filter === "today"
          ? fixtures.filter((f) => isToday(f.kickoff))
          : fixtures;
    return groupFixtures(list);
  }, [fixtures, filter]);

  const resetStore = useCallback((session: ShowSession) => {
    useShowStore.setState({
      session,
      overlayToken: session.overlay_token,
      snapshot: null,
      events: [],
      suggestions: [],
      transcript: [],
    });
  }, []);

  const resume = async () => {
    if (!activeSession || resuming) return;
    setResuming(true);
    setError(null);
    try {
      let session = activeSession;
      if (session.state !== "live") session = await api.transition(session.id, "live");
      resetStore(session);
      router.push(`/studio/${session.id}`);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Couldn't resume the session.");
      setResuming(false);
    }
  };

  const startShow = async (fixtureId: string) => {
    const profile = profiles.find((p) => p.id === profileId) ?? profiles[0];
    if (!profile) {
      setError("Create a show profile first: Show Profiles → New profile.");
      return;
    }
    setStarting(fixtureId);
    setError(null);
    try {
      let session = await api.createSession(profile.id, fixtureId);
      session = await api.transition(session.id, "armed");
      session = await api.transition(session.id, "live");

      const cfg = (profile.commentary_config ?? {}) as unknown as {
        mode?: string;
        voice?: string;
        language?: string;
      };
      resetStore(session);
      useShowStore.setState({
        commentaryMode: (cfg.mode as unknown as CommentaryMode | undefined) ?? DEFAULT_MODE,
        voice: cfg.voice ?? "en-US-Neural-A",
        language: cfg.language ?? "en",
      });
      router.push(`/studio/${session.id}`);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Couldn't start the show.");
      setStarting(null);
    }
  };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 lg:py-12">
      {/* Header */}
      <header className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-zinc-100">Match browser</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Pick a match and start a show.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {profiles.length > 1 && (
            <label className="flex items-center gap-2 text-sm text-zinc-400">
              Profile
              <select
                value={profileId}
                onChange={(e) => setProfileId(e.target.value)}
                className="rounded-lg border border-zinc-800 bg-zinc-900 px-2.5 py-1.5 text-sm text-zinc-200 [color-scheme:dark] focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              >
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
          )}

          <div role="tablist" aria-label="Filter matches" className="inline-flex rounded-full bg-zinc-900 p-1">
            {FILTERS.map(({ id, label }) => {
              const active = filter === id;
              return (
                <button
                  key={id}
                  role="tab"
                  aria-selected={active}
                  onClick={() => setFilter(id)}
                  className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                    active ? "bg-zinc-700 text-zinc-50" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  {label}
                  <span className={`ml-1.5 text-xs ${active ? "text-emerald-400" : "text-zinc-500"}`}>
                    {counts[id]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Error */}
      {error && (
        <div
          role="alert"
          className="mt-6 flex items-start gap-3 rounded-xl border border-red-900/60 bg-red-950/30 p-4 text-sm text-red-200"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          <p className="flex-1">{error}</p>
          <button
            onClick={() => setError(null)}
            aria-label="Dismiss error"
            className="rounded p-0.5 text-red-300 hover:bg-red-900/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Active session */}
      {activeSession && (
        <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-emerald-800/50 bg-emerald-950/30 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-sm font-medium text-emerald-100">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60 motion-reduce:animate-none" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-600" />
              </span>
              You have a show in progress
              <span className="rounded-full bg-emerald-900/50 px-2 py-0.5 text-xs font-normal capitalize text-emerald-300">
                {activeSession.state}
              </span>
            </p>
            <p className="mt-0.5 truncate text-sm text-emerald-200/70">Match {activeSession.match_id}</p>
          </div>
          <button
            onClick={resume}
            disabled={resuming}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-emerald-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 disabled:opacity-60"
          >
            {resuming ? "Resuming…" : "Resume show"}
            {!resuming && <ChevronRight className="h-4 w-4" aria-hidden />}
          </button>
        </div>
      )}

      {/* Content */}
      <main className="mt-8 space-y-10">
        {loading ? (
          <LoadingList />
        ) : grouped.length === 0 ? (
          <EmptyState filter={filter} hasAny={fixtures.length > 0} onReset={() => setFilter("all")} />
        ) : (
          grouped.map((day) => (
            <section key={day.key} aria-labelledby={`day-${day.key}`}>
              <h2 id={`day-${day.key}`} className="text-lg font-semibold text-zinc-100">
                {day.label}
              </h2>
              <div className="mt-4 space-y-6">
                {day.competitions.map((comp) => (
                  <div key={comp.name}>
                    <h3 className="mb-2 text-sm font-medium text-zinc-400">{comp.name}</h3>
                    <ul className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/40">
                      {comp.fixtures.map((f) => (
                        <FixtureRow
                          key={f.id}
                          fixture={f}
                          starting={starting === f.id}
                          disabled={starting !== null}
                          onStart={() => startShow(f.id)}
                        />
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          ))
        )}
      </main>
    </div>
  );
}

/* ---------- pieces ---------- */

function FixtureRow({
  fixture,
  starting,
  disabled,
  onStart,
}: {
  fixture: Fixture;
  starting: boolean;
  disabled: boolean;
  onStart: () => void;
}) {
  const isLive = fixture.status === "live";
  const isFinished = fixture.status === "ft";

  return (
    <li className="grid grid-cols-[1fr_auto] items-center gap-x-4 gap-y-3 p-4 transition-colors hover:bg-zinc-900/80 sm:grid-cols-[1fr_auto_auto] sm:px-5">
      <div className="grid min-w-0 grid-cols-[1fr_auto_1fr] items-center gap-3 sm:gap-5">
        <TeamLine team={fixture.home} />
        <div className="flex w-16 flex-col items-center justify-center text-center">
          {isLive ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-red-600/20 px-2 py-0.5 text-xs font-semibold text-red-300">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500 motion-reduce:animate-none" />
              Live
            </span>
          ) : isFinished ? (
            <span className="text-xs font-medium text-zinc-500">Full time</span>
          ) : (
            <time dateTime={fixture.kickoff} className="text-sm font-medium tabular-nums text-zinc-300">
              {formatTime(fixture.kickoff)}
            </time>
          )}
        </div>
        <TeamLine team={fixture.away} align="right" />
      </div>

      <button
        onClick={onStart}
        disabled={disabled}
        aria-label={`Start show: ${fixture.home.name} vs ${fixture.away.name}`}
        className="col-span-2 inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-emerald-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50 sm:col-span-1"
      >
        <Play className="h-3.5 w-3.5" aria-hidden />
        {starting ? "Starting…" : "Start show"}
      </button>
    </li>
  );
}

function TeamLine({ team, align = "left" }: { team: Fixture["home"]; align?: "left" | "right" }) {
  const [failed, setFailed] = useState(false);
  const showCrest = Boolean(team.crestUrl) && !failed;

  return (
    <div
      className={`flex min-w-0 items-center gap-2.5 ${
        align === "right" ? "flex-col-reverse text-center sm:flex-row-reverse sm:text-right" : "flex-col text-center sm:flex-row sm:text-left"
      }`}
    >
      <div className="h-9 w-9 shrink-0">
        {showCrest ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={`${API_BASE}${team.crestUrl}`}
            alt=""
            className="h-full w-full object-contain"
            onError={() => setFailed(true)}
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center rounded-full bg-zinc-700 text-[10px] font-bold text-white"
            style={team.color ? { backgroundColor: team.color } : undefined}
          >
            {(team.shortName ?? team.name).slice(0, 3).toUpperCase()}
          </div>
        )}
      </div>
      <span className="min-w-0 truncate text-sm font-medium text-zinc-100 sm:text-base">{team.name}</span>
    </div>
  );
}

function LoadingList() {
  return (
    <div className="space-y-4" aria-busy="true" aria-label="Loading matches">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-[74px] animate-pulse rounded-2xl border border-zinc-800 bg-zinc-900/60 motion-reduce:animate-none" />
      ))}
    </div>
  );
}

function EmptyState({ filter, hasAny, onReset }: { filter: Filter; hasAny: boolean; onReset: () => void }) {
  const message =
    filter === "live"
      ? "No matches are live right now."
      : filter === "today"
        ? "No matches are scheduled for today."
        : "No fixtures are available yet.";
  return (
    <div className="rounded-2xl border border-dashed border-zinc-700 bg-zinc-900/40 px-6 py-14 text-center">
      <p className="text-base font-medium text-zinc-100">{message}</p>
      {hasAny && filter !== "all" && (
        <button
          onClick={onReset}
          className="mt-3 text-sm font-medium text-emerald-400 hover:text-emerald-300 focus:outline-none focus-visible:underline"
        >
          Show all matches
        </button>
      )}
    </div>
  );
}