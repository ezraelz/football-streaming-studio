"use client";
import Link from "next/link";
import { useParams, usePathname } from "next/navigation";
import { LayoutDashboard, MessageSquareText, ScrollText, Zap } from "lucide-react";
import { cn } from "@/lib/utility/utils";
import { focusRing } from "@/components/ui/button";

const TABS = [
  { slug: "", label: "Studio", icon: LayoutDashboard },
  { slug: "/commentary", label: "Commentary", icon: MessageSquareText },
  { slug: "/automation", label: "Automation", icon: Zap },
  { slug: "/log", label: "Log", icon: ScrollText },
];

/** Page-level tabs for everything belonging to one show. */
export function SessionNav() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const pathname = usePathname();
  const base = `/studio/${sessionId}`;

  return (
    <nav aria-label="Show sections" className="-mx-1 overflow-x-auto px-1">
      <ul className="flex min-w-max gap-1 border-b border-zinc-800">
        {TABS.map(({ slug, label, icon: Icon }) => {
          const href = base + slug;
          const active = slug === "" ? pathname === base : pathname.startsWith(href);
          return (
            <li key={label}>
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "-mb-px flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors",
                  focusRing,
                  active
                    ? "border-emerald-500 text-zinc-50"
                    : "border-transparent text-zinc-400 hover:text-zinc-100",
                )}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
