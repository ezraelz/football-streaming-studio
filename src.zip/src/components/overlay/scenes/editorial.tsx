"use client";
import { useEffect, useState } from "react";
import { EditorialCard } from "@/lib/api/client";

// --- Payload types ---

interface TeamRef { name: string; color: string }

interface FixtureIntroPayload {
  competition: string;
  home: TeamRef;
  away: TeamRef;
  kickoff_label: string;
  venue?: string;
}

interface SummaryPayload {
  competition: string;
  home: TeamRef;
  away: TeamRef;
  score: { home: number; away: number };
  goals: Array<{ minute: number; player: string; team: string }>;
}

interface CountdownPayload {
  competition: string;
  home_name: string;
  away_name: string;
  kickoff: string;
}

interface LineupsPayload {
  home: { formation: string; players: Array<{ name: string; number: number; position: string }> };
  away: { formation: string; players: Array<{ name: string; number: number; position: string }> };
}

interface StandingsPayload {
  competition: string;
  rows: Array<{ position: number; team: string; played: number; points: number }>;
}

interface FormPayload {
  team: string;
  results: Array<{ outcome: "W" | "D" | "L"; opponent: string; score: string }>;
}

interface H2HPayload {
  meetings: Array<{ date: string; home: string; away: string; score: string }>;
}

interface TopScorersPayload {
  competition: string;
  players: Array<{ name: string; team: string; goals: number }>;
}

// --- Scene dispatcher ---

export function EditorialScene({ card }: { card: EditorialCard | null }) {
  if (!card || !card.visible) return null;

  switch (card.card_type) {
    case "fixture_intro":
      return <FixtureIntroCard payload={card.payload as unknown as FixtureIntroPayload} />;
    case "lineups":
      return <LineupsCard payload={card.payload as unknown as LineupsPayload} />;
    case "standings":
      return <StandingsCard payload={card.payload as unknown as StandingsPayload} />;
    case "form":
      return <FormCard payload={card.payload as unknown as FormPayload} />;
    case "head_to_head":
      return <H2HCard payload={card.payload as unknown as H2HPayload} />;
    case "top_scorers":
      return <TopScorersCard payload={card.payload as unknown as TopScorersPayload} />;
    case "match_summary":
      return <SummaryCard payload={card.payload as unknown as SummaryPayload} />;
    case "countdown":
      return <CountdownCard payload={card.payload as unknown as CountdownPayload} />;
    default:
      return <CustomCard title={card.title} payload={card.payload} />;
  }
}

// --- Shared ---

function TeamBadge({ name, color, crest_url }: { name: string; color: string; crest_url?: string | null }) {
  const [imgFailed, setImgFailed] = useState(false);
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-20 w-20">
        {crest_url && !imgFailed ? (
          <img
            src={`http://127.0.0.1:8000${crest_url}`}
            alt={name}
            className="h-full w-full object-contain"
            onError={() => setImgFailed(true)}
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center rounded-full border-2 border-white/20 text-xl font-black text-white"
            style={{ backgroundColor: color }}
          >
            {name.slice(0, 2).toUpperCase()}
          </div>
        )}
      </div>
      <div className="mt-2 text-lg font-bold uppercase tracking-wide text-white">{name}</div>
    </div>
  );
}

// --- Cards ---

function FixtureIntroCard({ payload }: { payload: FixtureIntroPayload }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/70">
      <div className="text-center">
        <div className="text-sm font-semibold uppercase tracking-widest text-emerald-400">
          {payload.competition}
        </div>
        <div className="mt-6 flex items-center gap-12">
          <TeamBadge {...payload.home} />
          <div className="text-6xl font-black text-white/40">VS</div>
          <TeamBadge {...payload.away} />
        </div>
        <div className="mt-8 text-2xl font-medium text-white/80">{payload.kickoff_label}</div>
        {payload.venue && <div className="mt-2 text-sm text-white/50">{payload.venue}</div>}
      </div>
    </div>
  );
}

function SummaryCard({ payload }: { payload: SummaryPayload }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-8">
      <div className="w-full max-w-3xl">
        <div className="text-center text-sm uppercase tracking-widest text-emerald-400">Full Time</div>
        <div className="mt-4 flex items-center justify-center gap-16">
          <TeamBadge {...payload.home} />
          <div className="text-7xl font-black text-white">{payload.score.home} – {payload.score.away}</div>
          <TeamBadge {...payload.away} />
        </div>
        <ul className="mt-8 space-y-2">
          {payload.goals.map((g, i) => (
            <li key={i} className="flex items-center gap-2 text-white/80">
              <span className="text-xs text-white/40">{g.minute}&apos;</span>
              <span>{g.player}</span>
              <span className="text-xs text-white/40">({g.team})</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function CountdownCard({ payload }: { payload: CountdownPayload }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const diff = now === null ? 0 : Math.max(0, new Date(payload.kickoff).getTime() - now);
  const hours = Math.floor(diff / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
      <div className="text-sm uppercase tracking-widest text-emerald-400">{payload.competition}</div>
      <div className="mt-4 text-3xl font-medium text-white">{payload.home_name} vs {payload.away_name}</div>
      <div className="mt-8 flex gap-6">
        {[["Hours", hours], ["Minutes", minutes], ["Seconds", seconds]].map(([label, value]) => (
          <div key={label as string} className="flex flex-col items-center">
            <div className="text-6xl font-black tabular-nums text-white">{String(value).padStart(2, "0")}</div>
            <div className="mt-1 text-xs uppercase tracking-widest text-white/50">{label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LineupsCard({ payload }: { payload: LineupsPayload }) {
  return (
    <div className="absolute inset-0 bg-black/80 p-12">
      <div className="grid h-full grid-cols-2 gap-8">
        {(["home", "away"] as const).map((side) => {
          const team = payload[side];
          return (
            <div key={side} className="flex flex-col">
              <div className="mb-4 text-sm uppercase tracking-widest text-emerald-400">{team.formation}</div>
                <ul className="space-y-1">
                {team.players.map((p, i) => (
                    <li key={`${p.number ?? "x"}-${p.name}-${i}`} className="flex items-center gap-3 text-white/80">
                    <span className="w-6 text-right text-xs text-white/40">{p.number ?? "—"}</span>
                    <span>{p.name}</span>
                    <span className="text-xs text-white/40">{p.position}</span>
                    </li>
                ))}
                </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StandingsCard({ payload }: { payload: StandingsPayload }) {
  return (
    <div className="absolute inset-0 bg-black/80 p-12">
      <div className="mb-4 text-sm uppercase tracking-widest text-emerald-400">{payload.competition}</div>
      <table className="w-full">
        <thead>
          <tr className="text-xs uppercase tracking-widest text-white/50">
            <th className="w-12 text-left">#</th>
            <th className="text-left">Team</th>
            <th className="w-16 text-right">P</th>
            <th className="w-16 text-right">Pts</th>
          </tr>
        </thead>
        <tbody>
          {payload.rows.map((r) => (
            <tr key={r.position} className="border-t border-white/10 text-white/80">
              <td className="py-2">{r.position}</td>
              <td>{r.team}</td>
              <td className="text-right">{r.played}</td>
              <td className="text-right font-bold">{r.points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FormCard({ payload }: { payload: FormPayload }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/70">
      <div>
        <div className="text-center text-sm uppercase tracking-widest text-emerald-400">Recent Form</div>
        <div className="mt-4 text-center text-2xl font-bold text-white">{payload.team}</div>
        <div className="mt-8 flex gap-3">
          {payload.results.map((r, i) => (
            <div
              key={i}
              className={`flex h-16 w-16 items-center justify-center rounded text-2xl font-black text-white ${
                r.outcome === "W" ? "bg-emerald-600" : r.outcome === "D" ? "bg-zinc-600" : "bg-red-600"
              }`}
            >
              {r.outcome}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function H2HCard({ payload }: { payload: H2HPayload }) {
  return (
    <div className="absolute inset-0 bg-black/80 p-12">
      <div className="mb-4 text-sm uppercase tracking-widest text-emerald-400">Head to Head</div>
      <ul className="space-y-2">
        {payload.meetings.map((m, i) => (
          <li key={i} className="flex items-center justify-between border-t border-white/10 py-2 text-white/80">
            <span className="text-xs text-white/40">{m.date}</span>
            <span>{m.home} — {m.away}</span>
            <span className="font-bold">{m.score}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TopScorersCard({ payload }: { payload: TopScorersPayload }) {
  return (
    <div className="absolute inset-0 bg-black/80 p-12">
      <div className="mb-4 text-sm uppercase tracking-widest text-emerald-400">{payload.competition} · Top Scorers</div>
      <ul className="space-y-2">
        {payload.players.map((p, i) => (
          <li key={i} className="flex items-center justify-between border-t border-white/10 py-2 text-white/80">
            <span>{i + 1}. {p.name} <span className="text-xs text-white/40">({p.team})</span></span>
            <span className="text-xl font-bold">{p.goals}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CustomCard({ title, payload }: { title: string; payload: Record<string, unknown> }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-12">
      <div className="w-full max-w-3xl">
        <div className="text-sm uppercase tracking-widest text-emerald-400">{title}</div>
        <pre className="mt-4 overflow-auto rounded bg-white/5 p-4 text-xs text-white/70">
          {JSON.stringify(payload, null, 2)}
        </pre>
      </div>
    </div>
  );
}