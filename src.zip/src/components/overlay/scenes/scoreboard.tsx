import { MatchSnapshot } from "@/lib/types/types";
import { formatClock } from "@/lib/utility/utils";
import { useState } from "react";

export function ScoreboardScene({ snapshot }: { snapshot: MatchSnapshot }) {
  const stale = snapshot.freshness !== "fresh";
  return (
    <div className="flex items-start justify-center pt-[6%]">
      <div className="flex overflow-hidden rounded-xl border border-white/10 bg-black/75 shadow-2xl backdrop-blur-md">
        <TeamBar team={snapshot.home} side="home" />
        <div className="flex min-w-[180px] flex-col items-center justify-center bg-black/40 px-6">
          <div className="text-5xl font-black tabular-nums text-white">
            {snapshot.score.home} – {snapshot.score.away}
          </div>
          <div className="mt-1 text-sm font-semibold uppercase tracking-wider text-emerald-400">
            {formatClock(snapshot.minute, snapshot.period)}
          </div>
        </div>
        <TeamBar team={snapshot.away} side="away" />
      </div>
      {stale && (
        <div className="ml-3 self-center rounded bg-amber-600/90 px-2 py-1 text-xs font-bold text-black">
          DATA DELAYED
        </div>
      )}
    </div>
  );
}

function TeamBar({ team, side: _side }: { team: MatchSnapshot["home"]; side: "home" | "away" }) {
  const { name, color, crest_url } = team;
  const [imgFailed, setImgFailed] = useState(false);
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-20 w-20">
        {crest_url && !imgFailed ? (
          <img
            src={`http://127.0.0.1:8000${crest_url}`}
            alt={name}
            className="h-full w-full object-contain"
            onError={() => setImgFailed(true)}
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center rounded-full border-2 border-white/20 text-xl font-black text-white"
            style={{ backgroundColor: color }}
          >
            {name.slice(0, 2).toUpperCase()}
          </div>
        )}
      </div>
      <div className="mt-2 text-lg font-bold uppercase tracking-wide text-white">{name}</div>
    </div>
  );
}