"use client";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api, type EditorialCard } from "@/lib/api/client";
import { useSocket } from "@/lib/hooks/use-socket";
import { useMatchAvailability } from "@/lib/hooks/use-match-availability";
import { EyeOff, Plus, Radio, Trash2 } from "lucide-react";
import { cn } from "@/lib/utility/utils";
import { Button } from "@/components/ui/button";
import { ConfirmButton } from "@/components/ui/confirm-button";
import { Alert, EmptyState } from "@/components/ui/feedback";
import { Badge } from "@/components/ui/badge";
import { SectionLabel } from "@/components/ui/panel";
import {
  ZONES, ZONE_LABEL, isTickerCard, zoneOf,
  type TickerItem, type Zone,
} from "@/components/overlay/scenes/editorial";
import { buildNextMatchItems } from "@/lib/overlay/ticker";
import { inputClass } from "@/components/ui/form";
import { buildLiveScoreItems } from "@/lib/overlay/live-ticker";

type CardType =
  | "fixture_intro" | "countdown" | "match_summary" | "lineups" | "prediction"
  | "standings" | "top_scorers" | "head_to_head" | "form" | "shot_map" | "custom";
type AvailabilityFlag =
  | "stats" | "lineups" | "incidents" | "shotmap" | "xg"
  | "momentum" | "average_positions" | "player_stats"
  | "prediction" | "broadcasts" | "odds";

const REQUIRES: Record<CardType, AvailabilityFlag[]> = {
  fixture_intro: [],
  countdown:     [],
  match_summary: ["incidents"],
  lineups:       ["lineups"],
  standings:     [],
  top_scorers:   [],
  head_to_head:  [],
  prediction:    ["prediction"],
  form:          [],
  shot_map:      ["shotmap"],
  custom:        [],
};

const CARDS: { type: CardType; label: string; hint: string }[] = [
  { type: "fixture_intro", label: "Fixture intro", hint: "Kickoff, venue, teams" },
  { type: "countdown",     label: "Countdown",    hint: "Time to kickoff" },
  { type: "match_summary", label: "Match summary", hint: "Score + goals" },
  { type: "lineups",       label: "Line-ups",     hint: "Starting XI + bench" },
  { type: "standings",     label: "Standings",    hint: "League table" },
  { type: "top_scorers",   label: "Top scorers",  hint: "League scorer chart" },
  { type: "head_to_head",  label: "Head-to-head", hint: "Past meetings" },
  { type: "form",          label: "Recent form",  hint: "Last 5, both teams" },
  { type: "prediction",    label: "Prediction",   hint: "Model probabilities" },
  { type: "shot_map", label: "Shot map", hint: "Every shot with xG" },
];

const label = (t: string) =>
  t.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());

export function EditorialPanel() {
  const params = useParams<{ sessionId: string }>();
  const [cards, setCards] = useState<EditorialCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [tickerText, setTickerText] = useState("");
  const [tickerLabel, setTickerLabel] = useState("News");
  const [error, setError] = useState<string | null>(null);
  const { data: availability, loading: availabilityLoading } = useMatchAvailability(params.sessionId);

  const refresh = useCallback(async () => {
    try {
      setCards(await api.listEditorialCards(params.sessionId));
    } catch {
      setError("Couldn't load graphics cards.");
    } finally {
      setLoading(false);
    }
  }, [params.sessionId]);

  useEffect(() => { void refresh(); }, [refresh]);

  useSocket<EditorialCard>(`/ws/v1/show-sessions/${params.sessionId}`, (msg) => {
    if (msg.type === "editorial.update") void refresh();
  });

  const isAvailable = (cardType: CardType): boolean => {
    const required = REQUIRES[cardType] ?? [];
    if (required.length === 0) return true;
    if (!availability?.available) return true;
    return required.every((flag) => availability.available[flag] === true);
  };

  const reason = (cardType: CardType): string | null => {
    const required = REQUIRES[cardType] ?? [];
    if (!availability?.available) return null;
    const missing = required.filter((flag) => availability.available[flag] !== true);
    if (missing.length === 0) return null;
    return `No ${missing.join(", ")} data for this match`;
  };

  const guard = async (key: string, fn: () => Promise<unknown>, failure: string) => {
    setBusy(key);
    setError(null);
    try {
      await fn();
      await refresh();
    } catch (e) {
      setError(e instanceof Error && e.message ? `${failure} ${e.message}` : failure);
    } finally {
      setBusy(null);
    }
  };

  const create = (type: string) =>
    guard(type, async () => {
      await api.seedEditorialCard(params.sessionId, type);
      setAdding(false);
    }, "Couldn't create the card.");

  const show = (id: string) =>
    guard(id, () => api.broadcastEditorialCard(params.sessionId, id), "Couldn't show the card.");

  const hide = (id: string) =>
    guard(id, () => api.updateEditorialCard(params.sessionId, id, { visible: false }), "Couldn't hide the card.");

  const move = (c: EditorialCard, value: Zone | "auto") => {
    const { zone: _old, ...rest } = c.payload as Record<string, unknown>;
    return guard(
      c.id,
      () => api.updateEditorialCard(params.sessionId, c.id, {
        payload: value === "auto" ? rest : { ...rest, zone: value },
      }),
      "Couldn't move the card.",
    );
  };

  const publishTicker = (
    key: string,
    labelText: string,
    items: TickerItem[],
    source: "fixtures" | "manual" | "news",
  ) =>
    guard(key, async () => {
      if (items.length === 0) throw new Error("Nothing to show.");
      for (const old of cards.filter((c) => isTickerCard(c) && c.visible)) {
        await api.updateEditorialCard(params.sessionId, old.id, { visible: false });
      }
      const payload = { kind: "ticker", label: labelText, items, source };
      let card: EditorialCard;
      try {
        card = await api.createEditorialCard(params.sessionId, {
          card_type: "custom", title: labelText, payload,
        });
      } catch {
        card = await api.seedEditorialCard(params.sessionId, "custom");
        await api.updateEditorialCard(params.sessionId, card.id, { title: labelText, payload });
      }
      await api.broadcastEditorialCard(params.sessionId, card.id);
    }, "Couldn't publish the ticker.");

  const showNextMatches = () =>
    guard("ticker-next", async () => {
      const fixtures = await api.fixtures();
      const items = buildNextMatchItems(fixtures);
      if (items.length === 0) throw new Error("No upcoming fixtures found.");
      await publishTicker("ticker-next", "Next matches", items, "fixtures");
    }, "Couldn't build the next-matches ticker.");

  const showLiveScores = () =>
    guard("ticker-live", async () => {
      const data = await api.liveScores(params.sessionId);
      const items = buildLiveScoreItems(data.matches);
      if (items.length === 0) {
        throw new Error("No matches currently live.");
      }
      await publishTicker("ticker-live", "Live now", items, "fixtures");
    }, "Couldn't build the live-scores ticker.");

  const showMessage = async () => {
    const text = tickerText.trim();
    if (!text) return;
    await publishTicker("ticker-msg", tickerLabel, [{ text }], tickerLabel === "News" ? "news" : "manual");
    setTickerText("");
  };

  const hideAll = () =>
    guard("hide", () => api.hideAllEditorial(params.sessionId), "Couldn't hide the cards.");

  const remove = (id: string) =>
    guard(id, () => api.deleteEditorialCard(params.sessionId, id), "Couldn't delete the card.");

  // Auto-refresh the live-scores ticker every 30s while it's on air
  useEffect(() => {
    const live = cards.find(
      (c) => isTickerCard(c) && c.visible && (c.payload as { label?: string }).label === "Live now"
    );
    if (!live) return;

    const id = setInterval(async () => {
      try {
        const data = await api.liveScores(params.sessionId);
        const items = buildLiveScoreItems(data.matches);
        if (items.length === 0) {
          await api.updateEditorialCard(params.sessionId, live.id, { visible: false });
          return;
        }
        const payload = { ...live.payload, items };
        await api.updateEditorialCard(params.sessionId, live.id, { payload });
        await api.broadcastEditorialCard(params.sessionId, live.id);
      } catch {
        // Ignore — network blips shouldn't spam the panel
      }
    }, 30_000);

    return () => clearInterval(id);
  }, [cards, params.sessionId]);

  const onAir = cards.filter((c) => c.visible).length;
  const hasAvailability = !!availability?.available;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="primary" size="sm" onClick={() => setAdding((v) => !v)} aria-expanded={adding}>
          <Plus className="h-4 w-4" aria-hidden /> Add card
        </Button>
        <Button size="sm" onClick={hideAll} disabled={busy === "hide" || onAir === 0}>
          <EyeOff className="h-4 w-4" aria-hidden /> Hide all{onAir > 0 && ` (${onAir} on air)`}
        </Button>
        {availabilityLoading && (
          <span className="text-[11px] text-zinc-500">Checking availability…</span>
        )}
        {availability?.lineup_status && (
          <Badge tone={availability.lineup_status === "confirmed" ? "live" : undefined}>
            Lineups: {availability.lineup_status}
          </Badge>
        )}
      </div>

      {adding && (
        <div className="rounded-xl border border-zinc-700 bg-zinc-950 p-3">
          <SectionLabel>Create from match data</SectionLabel>
          <div className="flex flex-wrap gap-1.5">
            {CARDS.map(({ type, label: cardLabel, hint }) => {
              const ok = isAvailable(type);
              const why = reason(type);
              return (
                <Button
                  key={type}
                  size="sm"
                  onClick={() => create(type)}
                  disabled={busy === type || !ok}
                  loading={busy === type}
                  title={!ok ? (why ?? "Unavailable") : hint}
                >
                  {cardLabel}
                </Button>
              );
            })}
          </div>
          {hasAvailability && (
            <div className="mt-2 rounded border border-zinc-800 bg-zinc-900/50 p-2 text-[10px] text-zinc-500">
              <div>
                available:{" "}
                {Object.entries(availability!.available)
                  .filter(([, v]) => v)
                  .map(([k]) => k)
                  .join(", ") || "—"}
              </div>
              {availability!.stat_keys && availability!.stat_keys.length > 0 && (
                <div className="mt-1 truncate">stats: {availability!.stat_keys.join(", ")}</div>
              )}
            </div>
          )}
          <p className="mt-2 text-xs text-zinc-400">Cards are created off-air. Press Show when you&apos;re ready.</p>
        </div>
      )}

      <p className="text-xs text-zinc-400">
        Cards appear on the <strong className="text-zinc-200">main screen</strong>, a{" "}
        <strong className="text-zinc-200">left or right corner</strong>, or the{" "}
        <strong className="text-zinc-200">bottom strip</strong> (the ticker bar runs underneath). &ldquo;Auto&rdquo; picks by card type
        (line-ups in the centre, standings and form in the left corner, top scorers in the right corner, head-to-head along the bottom).
      </p>

      <div className="rounded-xl border border-zinc-800 bg-zinc-950/50 p-3">
        <SectionLabel>Ticker bar (scrolls along the bottom)</SectionLabel>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={showNextMatches} loading={busy === "ticker-next"} disabled={busy !== null}>
            Show next matches
          </Button>
          <Button size="sm" onClick={showLiveScores} loading={busy === "ticker-live"} disabled={busy !== null}>
            Show live scores
          </Button>
        </div>
        <form
          className="mt-2 flex flex-wrap gap-2"
          onSubmit={(e) => { e.preventDefault(); void showMessage(); }}
        >
          <select
            aria-label="Ticker label"
            value={tickerLabel}
            onChange={(e) => setTickerLabel(e.target.value)}
            className={`${inputClass} w-auto py-1.5 text-sm`}
          >
            <option>News</option><option>Info</option><option>Breaking</option>
          </select>
          <input
            aria-label="Ticker message"
            value={tickerText}
            onChange={(e) => setTickerText(e.target.value)}
            placeholder="Type a message to scroll…"
            className={`${inputClass} min-w-40 flex-1 py-1.5`}
          />
          <Button type="submit" size="sm" disabled={!tickerText.trim() || busy !== null} loading={busy === "ticker-msg"}>
            Show
          </Button>
        </form>
      </div>

      {error && <Alert tone="error" onDismiss={() => setError(null)}>{error}</Alert>}

      {loading ? (
        <p className="text-sm text-zinc-400">Loading…</p>
      ) : cards.length === 0 ? (
        <EmptyState title="No graphics yet" description="Add a line-up, standings or intro card to show before or after the match." />
      ) : (
        <ul className="flex flex-col gap-2">
          {cards.map((c) => (
            <li
              key={c.id}
              className={cn(
                "flex items-center gap-3 rounded-xl border px-3 py-2.5",
                c.visible ? "border-red-500/60 bg-red-500/10" : "border-zinc-800 bg-zinc-950/50",
              )}
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-zinc-100">{c.title}</p>
                <div className="mt-0.5 flex items-center gap-1.5">
                  <Badge>{isTickerCard(c) ? "Ticker" : label(c.card_type)}</Badge>
                  {c.visible && <Badge tone="live">On air</Badge>}
                </div>
                {!isTickerCard(c) && (
                  <select
                    aria-label={`Screen position for ${c.title}`}
                    value={(c.payload as { zone?: string }).zone ?? "auto"}
                    onChange={(e) => move(c, e.target.value as Zone | "auto")}
                    disabled={busy === c.id}
                    className={`${inputClass} mt-2 w-auto py-1 text-xs`}
                  >
                    <option value="auto">
                      Auto · {ZONE_LABEL[zoneOf({ card_type: c.card_type, payload: { ...c.payload, zone: undefined } })]}
                    </option>
                    {ZONES.filter((z) => z !== "ticker").map((z) => (
                      <option key={z} value={z}>{ZONE_LABEL[z]}</option>
                    ))}
                  </select>
                )}
              </div>
              {c.visible ? (
                <Button size="sm" onClick={() => hide(c.id)} disabled={busy === c.id} loading={busy === c.id}>
                  <EyeOff className="h-3.5 w-3.5" aria-hidden /> Hide
                </Button>
              ) : (
                <Button size="sm" onClick={() => show(c.id)} disabled={busy === c.id} loading={busy === c.id}>
                  <Radio className="h-3.5 w-3.5" aria-hidden /> Show
                </Button>
              )}
              <ConfirmButton
                variant="ghost"
                size="icon"
                confirmLabel="Delete?"
                ariaLabel={`Delete ${c.title}`}
                icon={<Trash2 className="h-4 w-4" aria-hidden />}
                onConfirm={() => remove(c.id)}
                className="text-zinc-400 hover:text-red-300"
              />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}